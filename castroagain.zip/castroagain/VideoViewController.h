//
//  VideoViewController.h
//  castroagain
//
//  Created by Sivak Khodaverdian on 10/24/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

@interface VideoViewController : UIViewController
@property (strong, nonatomic) MPMoviePlayerController *moviePlayer;


@end
