//
//  WebSpeech1ViewController.h
//  castroagain
//
//  Created by Sivak Khodaverdian on 6/18/14.
//
//

#import <UIKit/UIKit.h>

@interface WebSpeech1ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIWebView *myWebView;

@end
