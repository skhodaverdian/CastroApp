//
//  WebSpeech1ViewController.m
//  castroagain
//
//  Created by Sivak Khodaverdian on 6/18/14.
//
//

#import "WebSpeech1ViewController.h"

@interface WebSpeech1ViewController ()

@end

@implementation WebSpeech1ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    [self.myWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.marxists.org/history/cuba/archive/castro/1959/01/03.htm"]]];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
