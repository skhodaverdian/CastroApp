//
//  OpeningScreenViewController.h
//  castroagain
//
//  Created by Sivak Khodaverdian on 10/5/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OpeningScreenViewController : UITableViewController <UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UINavigationItem *navbarHome;

@end
