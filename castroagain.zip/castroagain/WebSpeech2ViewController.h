//
//  WebSpeech2ViewController.h
//  castroagain
//
//  Created by Sivak Khodaverdian on 6/22/14.
//
//

#import <UIKit/UIKit.h>

@interface WebSpeech2ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIWebView *myWebView2;

@end
