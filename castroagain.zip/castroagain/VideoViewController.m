//
//  VideoViewController.m
//  castroagain
//
//  Created by Sivak Khodaverdian on 10/24/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "VideoViewController.h"

@interface VideoViewController ()

@end

@implementation VideoViewController
@synthesize moviePlayer;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void) playMovieFinished:(NSNotification*)theNotification {
    
    self.moviePlayer = [theNotification object];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:self.moviePlayer];
    
    [self.moviePlayer.view removeFromSuperview];
}

-(void) loadVideo {
    
    moviePlayer = [[MPMoviePlayerController alloc]
                                            initWithContentURL:[NSURL fileURLWithPath:@"iphoneprj.m4v"]];
    
    [moviePlayer.view setFrame:CGRectMake(10.0, 10.0, 300.0, 375.0)];
  //  self.moviePlayer.contentURL = url;
 //   self.moviePlayer.shouldAutoplay = NO;
     [self.moviePlayer.view setBackgroundColor:[UIColor yellowColor]];
    [self.view addSubview:moviePlayer.view];
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self selector:@selector(playMovieFinished:) name:MPMoviePlayerPlaybackDidFinishNotification object:moviePlayer];
    
    [moviePlayer play];
}



- (void)viewDidLoad
{
   // [self loadVideo];
    
  //  NSString *movieFile = [[NSBundle mainBundle] pathForResource:@"iphoneprj" ofType:@"m4v"];
  //  self.moviePlayer = [[MPMoviePlayerController alloc] initWithContentURL:[NSURL fileURLWithPath:@"iphoneprj.m4v"]];
    
  //  self.moviePlayer.allowsAirPlay = YES;
  //  [self.moviePlayer.view setFrame:CGRectMake(0.0, 0.0, 320, 476)];
    
    
    [super viewDidLoad];
    
    
  //  [self.view addSubview:self.moviePlayer.view];
   // [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playMovieFinished:) name:MPMoviePlayerPlaybackDidFinishNotification object:self.moviePlayer];
    
     //  [self.moviePlayer play];
}

- (void)viewDidUnload
{
    [self setMoviePlayer:nil];
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void) viewDidAppear:(BOOL)animated {
    
   // self.moviePlayer = [[MPMoviePlayerController alloc] init];
    
  //  [self.moviePlayer setContentURL:self.movieURL];    
    
    self.moviePlayer = [[MPMoviePlayerController alloc] initWithContentURL:[NSURL fileURLWithPath:@"iphoneprj.m4v"]];
    [self.moviePlayer prepareToPlay];
    
    [self.moviePlayer.view setFrame:CGRectMake (145, 20, 155, 100)];
    [self.view addSubview:self.moviePlayer.view];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playMovieFinished:) name:MPMoviePlayerPlaybackDidFinishNotification object:self.moviePlayer];
    
    
    [self.moviePlayer play];
}

@end
