//
//  BiographyViewController.h
//  castroagain
//
//  Created by Sivak Khodaverdian on 10/18/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BiographyViewController : UIViewController

@end
