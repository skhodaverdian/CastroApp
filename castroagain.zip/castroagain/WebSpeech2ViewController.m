//
//  WebSpeech2ViewController.m
//  castroagain
//
//  Created by Sivak Khodaverdian on 6/22/14.
//
//

#import "WebSpeech2ViewController.h"

@interface WebSpeech2ViewController ()

@end

@implementation WebSpeech2ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSString *myHTML = @"<html><body><p>Hello, world!</p><br />To read the full speech click below<br /><a href='http://www.marxists.org/history/cuba/archive/castro/1960/07/09.htm'>My speech to the world</a></body></html>";
    [self.myWebView2 loadHTMLString:myHTML baseURL:nil];
   // [self.myWebView2 loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.marxists.org/history/cuba/archive/castro/1960/07/09.htm"]]];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
